#!/bin/bash

# Datos del reporte

server_name=$(hostname)
report_date=$(date +%d/%m/%Y" "%H:%M:%S)
uptime_server=$(uptime -p)

filesystem_data=()
FILESYSTEM=$(df -PH | sort -r -k 4 | grep -vE 'snapfuse|none|tmpfs' | tail -n +2 | awk '{print $5"|"$6}')

while IFS= read -r file; do
  use=$(echo "$file" | awk -F '|' '{print $1}' | cut -d'%' -f1)
  mount=$(echo "$file" | awk -F '|' '{print $2}')

  if [ "$use" -ge 80 ]; then
    status="Disco sobrepasa el 80%"
  else
    status="OK"
  fi

  # Agrega la información formateada a la variable filesystem_data
  filesystem_data+=("$mount|$use%|$status")
done <<<"$FILESYSTEM"

# Obtener el porcentaje de uso de la memoria RAM
memory_usage=$(free | awk '/Mem:/ {printf("%.0f", $3/$2 * 100.0)}')

# Obtener el tamaño total de la memoria RAM
total_memory=$(free -h | awk '/Mem:/ {print $2}' | cut -d'G' -f1)
total_memory="${total_memory}GB"

# Obtener el porcentaje de uso de la CPU (promedio del uso del usuario + sistema)
cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{printf("%.0f", $2)}')

# Obtener el número de cores del servidor
cores=$(lscpu | grep 'CPU(s):' | awk '{print $2}')

# Formatear y almacenar en la variable resource_data
resource_data+=("$cpu_usage%|$cores|$total_memory|$memory_usage%")

application_data=()
app=$(
  pgrep -f Djava.net.preferIPv4Stack
  pgrep -f tomcat
  pgrep -f httpd | tail -1
)

while IFS= read -r line; do
  jboss_eap=$(ps -fea | grep Djava.net.preferIPv4Stack | grep "$line" | grep jboss-eap | grep -v grep)
  jboss_as=$(ps -fea | grep Djava.net.preferIPv4Stack | grep "$line" | grep jboss-asi | grep -v grep)
  jboss4=$(ps -fea | grep Djava.net.preferIPv4Stack | grep "$line" | grep 'org.jboss.Main -c' | grep -v grep)
  tomcat=$(ps -fea | grep tomcat | grep "$line" | grep -v grep)
  apache=$(ps -fea | grep "$line" | grep httpd | grep -v grep)
  appcpu=$(top -b -n 1 -p "$line" | grep "$line" | awk '{printf("%.0f", $9)}')
  appmemmb=$(ps -p "$line" -orss=,args= | sort -b -k1,1n | awk '{printf("%.0f", $1/1024)}')
  appmemmb="${appmemmb}MB"
  appmem=$(top -b -n 1 -p "$line" | grep "$line" | awk '{printf("%.0f", $10)}')
  proceso=$(ps -fea | grep "$line" | grep -v grep)
  uptime=$(ps -o etime= -p "$line")

  if [ -n "$jboss_as" ]; then
    capa="JBoss AS"
  elif [ -n "$jboss_eap" ]; then
    capa="JBoss EAP"
  elif [ -n "$jboss4" ]; then
    capa="JBoss-4 GA "
  elif [ -n "$tomcat" ]; then
    capa="Apache Tomcat"
  elif [ -n "$apache" ]; then
    capa="Apache HTTPD"
  else
    capa="N/A"
  fi

  application_data+=("$capa|$proceso|$uptime|$appcpu%|$appmemmb|$appmem%")
done <<<"$app"

# Crear el archivo HTML
cat <<EOF >/tmp/reporte_health_check.html
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Health Check</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f9;
            color: #333;
        }
        .info {
            margin: 20px 0;
            font-size: 1.2em;
            background-color: #007acc;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        th, td {
            border: 1px solid #e0e0e0;
            text-align: center;
            padding: 12px;
        }
        th {
            background-color: #4caf50;
            color: #fff;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f4f4f9;
        }
        caption {
            font-size: 1.5em;
            margin: 10px 0;
            font-weight: bold;
            color: #007acc;
        }
        .section-title {
            background-color: #4caf50;
            color: #fff;
            font-weight: bold;
        }
        .spacer {
            height: 20px;
        }
    </style>
</head>
<body>

    <div class="info">
        <p>Server: $server_name</p>
        <p>Date: $report_date</p>
        <p>Uptime: $uptime_server</p>
    </div>

    <!-- Sección Filesystem -->
    <table>
        <caption>Report Health Check</caption>
        <thead>
            <tr>
                <th colspan="3" class="section-title">FILESYSTEM</th>
            </tr>
            <tr>
                <th>Filesystem</th>
                <th>%Use</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
EOF

for fs in "${filesystem_data[@]}"; do
  IFS='|' read -r filesystem uso mensaje <<<"$fs"
  cat <<EOF >>/tmp/reporte_health_check.html
            <tr>
                <td>$filesystem</td>
                <td>$uso</td>
                <td>$mensaje</td>
            </tr>
EOF
done

cat <<EOF >>/tmp/reporte_health_check.html
        </tbody>
    </table>

    <!-- Espacio entre secciones -->
    <div class="spacer"></div>

    <!-- Sección Consumo de Recursos -->
    <table>
        <thead>
            <tr>
                <th colspan="4" class="section-title">USAGE RESOURCES</th>
            </tr>
            <tr>
                <th>%Cpu</th>
                <th>Cores</th>
                <th>Total Mem</th>
                <th>%Mem</th>
            </tr>
        </thead>
        <tbody>
EOF

for resource in "${resource_data[@]}"; do
  IFS='|' read -r cpu core totalm mem <<<"$resource"
  cat <<EOF >>/tmp/reporte_health_check.html
            <tr>
                <td>$cpu</td>
                <td>$core</td>
                <td>$totalm</td>
                <td>$mem</td>
            </tr>
EOF
done

cat <<EOF >>/tmp/reporte_health_check.html
        </tbody>
    </table>

    <!-- Espacio entre secciones -->
    <div class="spacer"></div>

    <!-- Sección Aplicaciones -->
    <table>
        <thead>
            <tr>
                <th colspan="6" class="section-title">APPLICATIONS</th>
            </tr>
            <tr>
                <th>Middleware</th>
                <th>Process</th>
                <th>Uptime</th>
                <th>%Cpu usage</th>
				        <th>Mem MB usage</th>
				        <th>%Mem usage</th>
            </tr>
        </thead>
        <tbody>
EOF

for app in "${application_data[@]}"; do
  IFS='|' read -r capa proceso uptime appcpu appmemmb appmem <<<"$app"
  cat <<EOF >>/tmp/reporte_health_check.html
            <tr>
                <td>$capa</td>
                <td>$proceso</td>
                <td>$uptime</td>
                <td>$appcpu</td>
				        <td>$appmemmb</td>
				        <td>$appmem</td>
            </tr>
EOF
done

cat <<EOF >>/tmp/reporte_health_check.html
        </tbody>
    </table>

</body>
</html>
EOF
