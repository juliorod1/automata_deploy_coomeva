# proyecto_ansible

Tener presente que el comando pgrep cambia de acuerdo al SO, validar antes de ejecutar. 
